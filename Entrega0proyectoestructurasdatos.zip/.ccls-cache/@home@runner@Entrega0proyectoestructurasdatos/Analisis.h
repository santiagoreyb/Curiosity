#ifndef _ANALISIS__H__
#define _ANALISIS__H__
#include <string>
class Analisis
{
protected:
char tipo;
std::string objeto ;
std::string comentario;

public:
Analisis();
~Analisis();
char ObtenerTipo();
std::string ObtenerObjeto();
std::string ObtenerComentario();
void fijarTipo(char);
void fijarObjeto(std::string);
void fijarComentario(std::string);
  
};

#include "Analisis.hxx"
#endif