#ifndef _MOVIMIENTO_
#define _MOVIMIENTO_

class movimiento
{
protected:
char tipo;
float magnitud;
char unidad[2] ;

public:



  
  



  
}

#include "Movimiento.hxx"