# include   "Puntointeres.h"

Analisis::Analisis(){
  tipo='f';
  unidad="";
  x=0;
  y=0;
}

std::char Puntointeres::ObtenerTipo() {
  return( tipo );
}

std::string Puntointeres::ObtenerObjeto() {
  return( objeto );
}
int Puntointeres::ObtenerTamano(){
  return(tamano);
}
std::string Puntointeres::ObtenerComentario() {
  return( comentario );
}
void Puntointeres::fijarTipo(std::char n_tipo) {
  this->tipo = n_tipo;
}

void Puntointeres::fijarObjeto(std::string n_objeto) {
  this->objeto = n_objeto;
}
void Puntointeres::fijarCoordenadas(float m,float m) {
  this->x = m;
  this->y = n;
}
void  Puntointeres:: fijarTamano(int t){
  this->tamano=t;
}