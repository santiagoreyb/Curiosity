# include "Curiosity.h"

# include <string>
#include <queue>
#include <vector>
#include <list>
Curiosity::Curiosity(){
  coord[0]= 0;
  coord[1]= 0;
}

std::vector<float> Curiosity::ObtenerCoord();
  return( coord[2] );
}
void Curiosity:: eliminarMovimientos(){
  cola_Movimientos.clear();
}
void Curiosity:: eliminarAnalisis(){
  cola_Analisis.clear();
}
void Curiosity:: eliminarPuntos(){
  lista_puntos.clear();
}

void Curiosity::Agregar_Movimiento(std::string linea_movimiento) {
  
}
void Curiosity::Agregar_Analisis(std::string linea_analisis) {
  
}
void Curiosity::Agregar_Puntointeres(std::string linea_puntointeres) {
  
}

std::queue<Movimientos> Curiosity::ObtenerMovimientos() {
  return( cola_Movimientos );
}
std::queue<Analisis> Curiosity::ObtenerAnalisis() {
  return( cola_Analisis );
}
void agregar_elemento(string tipo_comp, float tamano, string unidad_med, float coordX, float coordY) {
    // Verificar que se hayan proporcionado todos los datos requeridos
    if (tipo_comp.empty() || tamano <= 0 || unidad_med.empty()) {
        cout << "(Formato erróneo) La información del elemento no corresponde a los datos esperados (tipo, tamaño, unidad, x, y)." << endl;
        return;
    }
    
    // Crear el elemento con los datos proporcionados
    Puntointeres nuevo_elemento = {tipo_comp, tamano, unidad_med, coordX, coordY};
    
    // Agregar el elemento a la lista de puntos de interés
    lista_puntos.push_back(nuevo_elemento);
    
    // Imprimir mensaje de éxito
    cout << "El elemento ha sido agregado exitosamente." << endl;
}
