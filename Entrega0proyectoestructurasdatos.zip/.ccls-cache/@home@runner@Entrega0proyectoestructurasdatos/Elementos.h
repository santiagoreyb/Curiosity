#ifndef _ELEMENTOS_
#define _ELEMENTOS_
#include <string>
#include <queue>
#include <list>
#include <vector>
#include "Analisis.h"
#include "Movimiento.h"
class Elementos
{

protected:
std::list<Analisis> lista_analisis;
std::list<Movimiento> lista_movimiento;


public:
Elementos();
~Elementos();
char ObtenerTipo();
float ObtenerMagnitud();
std::string ObtenerUnidad();
void fijarTipo(char);
void fijarMagnitud(float);
void fijarUnidad(std::string);
  
};

#include "Elementos.hxx"
#endif