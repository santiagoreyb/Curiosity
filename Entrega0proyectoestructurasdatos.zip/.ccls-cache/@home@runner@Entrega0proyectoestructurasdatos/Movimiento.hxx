#include "Movimiento.h"
#include <string>

Movimiento::Movimiento(){
  tipo='f';
  magnitud=0;
  unidad="--";
}

std::char Movimiento::ObtenerTipo() {
  return( tipo );
}

float Movimiento::ObtenerMagnitud() {
  return( magnitud );
}

std::string Movimiento::ObtenerUnidad() {
  return( unidad );
}
void Movimiento::fijarTipo(std::char n_tipo) {
  this->tipo = n_tipo;
}

void Movimiento::fijarMagnitud(std::float n_magnitud) {
  this->magnitud = n_magnitud;
}
void Movimiento::fijarObjeto(std::string n_unidad) {
  if(n_unidad.legnth()<=2){
  this->comentario = n_unidad;
    }
  else
    this->comentario = "--";
}