#ifndef _PUNTOINITERES__H__
#define _PUNTOINITERES__H__
#include <string>
#include <vector>
class Puntointeres
{
protected:
char tipo;
char unidad[2] ;
float tamano;
float x;
float y;

public:
Puntointeres();
~Puntointeres();
char ObtenerTipo();
std::string ObtenerUnidad();
int ObtenerTamano();
std::vector<float> ObtenerCoordenas();
void fijarTipo(char);
void fijarUnidad(std::string);
void fijarTamano(int);
void fijarCoordenadas(float, float);
  
};

#include "Puntointeres.hxx"
#endif