#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <list>
#include "Curiosity.h"
#include <cmath>
/*
  Compilar:
         g++ -std=c++11 main.cpp -o main
    Ejecutar:
        ./main
    prueba:
      cargar_comandos Comandos1.txt
      cargar_comandos Comandos2.txt
      cargar_comandos Comandos3.txt

      simular_comandos 0 0

  Depuracion:
      g++ -std=c++11 -g -o main *Curiosity.hxx
*/
//Comandos.txt
using namespace std;
int cmdos(string cmdo);
vector<string> splitargms(string str);
void ayuda();
bool archvo_vacio(ifstream& n_archivo);
void cargar_comandos(string nombre_archivo, Curiosity &curiosity);
void cargar_puntos(string nombre_archivo, Curiosity &curiosity);
void guardar(string tipo_archivo, string nombre_archivo, Curiosity &curiosity);

int main() {

  string comand, linea_comando, nombre_archivo, tipo_comp, unidadMedida, tipo_archivo;
  Curiosity curiosity;
  vector<string> argmts;
  int opcion=1;
  float tamano, x, y;
  cout << "Ingrese el comando deseado" << endl;
  cout << "Ingrese | ayuda | para deplegar comandos" << endl;
  while(opcion!=0){
    cout<<"$";

    getline(cin, linea_comando);
    argmts = splitargms(linea_comando);
        comand = argmts[0];
        opcion = cmdos(comand);

    switch(opcion){
      case 0:
      if(argmts.size()!=1){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        }
    break;
    case 1:
      if(argmts.size()!=2){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
       nombre_archivo = argmts[1];
        cargar_comandos(nombre_archivo, curiosity);
        }
    break;
    case 2:
      if(argmts.size()!=2){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
      nombre_archivo = argmts[1];
      cargar_puntos( nombre_archivo, curiosity);
        }
    break;
    case 3:
    if(argmts.size()!=4){
        
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
      curiosity.Agregar_Movimiento(linea_comando);
        }
    break;
    case 4:
      if(argmts.size()!=4){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
      curiosity.Agregar_Analisis(linea_comando);
        }
    break;
    case 5:
      if(argmts.size()!=6){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        curiosity.Agregar_Puntointeres(linea_comando);
       /* tipo_comp = argmts[1];
        tamano = stof(argmts[2]);
        unidadMedida = argmts[3];
        x = stof(argmts[4]);
        y = stof(argmts[5]);
        curiosity.agregar_elemento(tipo_comp, tamano, unidadMedida, x, y);*/
        }
    break;
    case 6:
      if(argmts.size()!=3){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        nombre_archivo = argmts[1];
        tipo_archivo = argmts[2];
        curiosity.guardar(nombre_archivo, tipo_archivo);
        }
    break;
    case 7:
      if(argmts.size()!=3){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
      x = stof(argmts[1]);
      y = stof(argmts[2]);
      curiosity.simular_comandos1(x, y);
        }
    break;
    case 8:
      if(argmts.size()!=1){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        }
    break;
    case 9:
      if(argmts.size()!=5){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        }
    break;
    case 10:
      if(argmts.size()!=2){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        }
    break;
    case 11:
      if(argmts.size()!=1){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        }
    break;

    case 13:
      cout<<"Ingrese un comando valido"<<endl;
      cout<<"Ingrese el comando ayuda para desplegar la lista de comandos"<<endl;
    break;
    case 14:
      if(argmts.size()!=1){
        cout<<"Ingreso de parametros erroneo"<< endl;
      }
      else{
      cout<<"comando valido :)"<< endl;
        ayuda();
        }

      break;

    default:
    cout<<"Ingrese un comando valido"<<endl;
    break;
    }
  }
  cout<<"Fin"<<endl;
  }

int cmdos(string cmdo){
  if(cmdo=="cargar_comandos"){
    return 1;
  }
  if(cmdo=="cargar_elementos"){
    return 2;
  }
  if(cmdo=="agregar_movimiento"){
    return 3;
  }
  if(cmdo=="agregar_analisis"){
    return 4;
  }
  if(cmdo=="agregar_elemento"){
    return 5;
  }
  if(cmdo=="guardar"){
    return 6;
  }
  if(cmdo=="simular_comandos"){
    return 7;
  }
  if(cmdo=="ubicar_elementos"){
    return 8;
  }
  if(cmdo=="en_cuadrante"){
    return 9;
  }
  if(cmdo=="crear_mapa"){
    return 10;
  }
  if(cmdo=="ruta_mas_larga"){
    return 11;
  }
  if(cmdo=="salir"){
    return 0;
  }
  if(cmdo=="ayuda"){
    return 14;
  }
  else{
    return 13;
  }
}
vector<string> splitargms(string str){

  vector<string> comand_argms;
  int posInit = 0;
  int posFound = 0;
  string splitted;


    while (posFound >= 0) {
        posFound = str.find(' ', posInit);
        splitted = str.substr(posInit, posFound - posInit);
        posInit = posFound + 1;
        comand_argms.push_back(splitted);
    }

  return comand_argms;
}
void ayuda(){
  cout<<"Lista de comandos: "<<endl;
  cout<<"cargar_comandos   " <<endl;
  cout<<"cargar_elementos  "<<endl;
  cout<<"agregar_movimiento (Fomato: agregar_analisis tipo_analisis objeto comentario)"<<endl;
  cout<<"agregar_analisis  (Fomato: agregar_analisis tipo_analisis objeto comentario)"<<endl;
  cout<<"agregar_elemento   (Formato: agregar_elemento tipo_comp tamaño unidad_med coordX coordY)"<<endl;
  cout<<"guardar  (Fomato: guardar tipo_de_archivo nombre_de_archivo)"<<endl;
  cout<<"simular_comandos   (Formato: simular_comandos coordX coordY) "<<endl;
  cout<<"ubicar_elementos"<<endl;
  cout<<"en_cuadrante    (Formato: en_cuadrante coordX1 coordX2 coordY1 coordY2)"<<endl;
  cout<<"crear_mapa   (Formato: crear_mapa coeficiente_conectividad)"<<endl;
  cout<<"ruta_mas_larga"<<endl;
  cout<<"salir"<<endl;
  cout<<"ayuda"<<endl;
}
bool archvo_vacio(ifstream& n_archivo){
    return n_archivo.peek() == ifstream::traits_type::eof();
}

void cargar_comandos(string nombre_archivo, Curiosity &curiosity){

  unsigned int tipo, n_comandos=0, pos;

  std:: string linea_archivo, com_movimiento, com_analisis;

  cout << endl << "cargando archivo:  " << nombre_archivo << endl;
    ifstream archivo_lectura(nombre_archivo);

    // Verificar si el archivo existe
    if (!archivo_lectura) {
        cout << endl << nombre_archivo << ":    No se encuentra o no puede leerse" << endl;
        return;
    }
    // Verificar si el archivo esta vacio
    if (archvo_vacio(archivo_lectura)){
        cout << endl << nombre_archivo << ":    Esta vacio, no contiene ningun comando" << endl;
        return;
    }
  curiosity.eliminarMovimientos();
  curiosity.eliminarAnalisis();
  curiosity.eliminarOrden();
  cout<<"sobreescitro"<<endl;
   while(getline (archivo_lectura, linea_archivo))
    {
        if (linea_archivo[0] == '0'){
            // obtener en string los movimientos
            pos = linea_archivo.find("0");
            com_movimiento = linea_archivo.substr(pos+1);
            curiosity.Agregar_Movimiento(com_movimiento);
            
          n_comandos++;
        }
      else if(linea_archivo[0] == '1'){
            // obtener en string los analisis
            pos = linea_archivo.find("1");
            com_analisis = linea_archivo.substr(pos+1);
            curiosity.Agregar_Analisis(com_analisis);
            n_comandos++;
      }
      else{
        cout<<"Error en la lectura del archivo. No se puede cargar"<<endl;
         curiosity.eliminarMovimientos();
          curiosity.eliminarAnalisis();
        archivo_lectura.close();
          return;
      }
      }
      archivo_lectura.close();
    cout << endl << "Se han cargado " << n_comandos << " comandos" << endl;
}
void cargar_puntos(string nombre_archivo, Curiosity &curiosity){
  unsigned int n_puntos=0, pos;

  std:: string linea_archivo, linea_elemento;

  cout << endl << "cargando archivo:  " << nombre_archivo << endl;
    ifstream archivo_lectura(nombre_archivo);

    // Verificar si el archivo existe
    if (!archivo_lectura) {
        cout << endl << nombre_archivo << ":    No se encuentra o no puede leerse" << endl;
        return;
    }
    // Verificar si el archivo esta vacio
    if (archvo_vacio(archivo_lectura)){
        cout << endl << nombre_archivo << ":    Esta vacio, no contiene ningun comando" << endl;
        return;
    }
  curiosity.eliminarPuntos();
  cout<<"sobreescitro"<<endl;
   while(getline (archivo_lectura, linea_archivo)){
  curiosity.Agregar_Puntointeres(linea_archivo);
     n_puntos++;
   }
  archivo_lectura.close();
    cout << endl << "Se han cargado " << n_puntos << "Puntos de interes" << endl;
  
}
