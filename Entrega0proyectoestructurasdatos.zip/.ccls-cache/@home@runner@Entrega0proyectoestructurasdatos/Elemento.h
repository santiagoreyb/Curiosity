#ifndef _MOVIMIENTO_
#define _MOVIMIENTO_
#include <string>
#include "Analisis.h"
#include "mo"
class Movimiento
{
protected:
char tipo;
float magnitud;
char unidad[2] ;

public:
Movimiento();
~Movimiento();
char ObtenerTipo();
float ObtenerMagnitud();
std::string ObtenerUnidad();
void fijarTipo(char);
void fijarMagnitud(float);
void fijarUnidad(std::string);
  
};

#include "Movimiento.hxx"
#endif