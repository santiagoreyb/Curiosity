#ifndef _CURIOSITY__H_
#define _CURIOSITY__H_
#include <string>
#include "Puntointeres.h"
#include "Analisis.h"
#include "Movimiento.h"
#include <queue>
#include <vector>
#include <list>

class Curiosity
{
protected:
float coord[2];
std::queue<Analisis> cola_Analisis;
std::queue<Movimiento> cola_Movimientos;
std::list<Puntointeres> lista_puntos;

public:
Curiosity();

std::vector<float> ObtenerCoord();
std::queue<Movimiento> ObtenerColaMovimientos();
std::queue<Analisis> ObtenerColaAnalisis();
std::list<Puntointeres> ObtenerlistaPuntos();
void agregarMovimiento(Movimiento);
void agregarAnalisis(Analisis);
void agreagarPunto(Puntointeres);
void fijarCoordenadas(float, float);
void eliminarMovimientos();
void eliminarAnalisis();
void eliminarPuntointeres();
void agregar_elemento(std::string tipo_comp, float tamano, std::string unidad_med, float coordX, float coordY);
};

#include "Curiosity.hxx"
#endif